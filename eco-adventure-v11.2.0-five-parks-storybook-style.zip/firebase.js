/* ===== V9.1 Google 登入、雲端存檔與每週排行榜 ===== */
let cloudDb=null, cloudAuth=null, cloudUser=null, cloudReady=false, cloudSaveTimer=null, cloudLoading=false;
let cloudRetryTimer=null, cloudWriteInProgress=false, cloudWriteQueued=false, cloudIsAdmin=false, cloudPlayerUnsubscribe=null;
let publicBaseSyncTimer=null,publicBaseWriteInProgress=false,publicBaseWriteQueued=false,lastPublicBaseFingerprint='';
let adminPlayersCache=[],adminQuestionsCache=[],adminEventsCache=[],adminRankingCache=[],adminEditingEventId=null;
window.ECO_ACTIVE_EVENTS=[];window.ECO_CUSTOM_QUESTIONS=[];

function currentWeekId(date=new Date()){
  const d=new Date(Date.UTC(date.getFullYear(),date.getMonth(),date.getDate()));
  const day=d.getUTCDay()||7; d.setUTCDate(d.getUTCDate()+4-day);
  const yearStart=new Date(Date.UTC(d.getUTCFullYear(),0,1));
  const week=Math.ceil((((d-yearStart)/86400000)+1)/7);
  return `${d.getUTCFullYear()}-W${String(week).padStart(2,'0')}`;
}
function weekDateRange(date=new Date()){
  const d=new Date(date),day=d.getDay()||7; d.setDate(d.getDate()-day+1);d.setHours(0,0,0,0);
  const end=new Date(d);end.setDate(end.getDate()+6);const f=x=>`${x.getMonth()+1}/${x.getDate()}`;return `${f(d)}－${f(end)}`;
}
function ensureWeeklyLocal(){
 const id=currentWeekId(),ruleVersion='v9.8-monday-sunday';
 if(!st.weekly||st.weekly.weekId!==id||st.weekly.ruleVersion!==ruleVersion){
   st.weekly={weekId:id,ruleVersion,points:0,completedKeys:[],perfectKeys:[]};
 }
 st.weekly.completedKeys=Array.isArray(st.weekly.completedKeys)?st.weekly.completedKeys:[];
 st.weekly.perfectKeys=Array.isArray(st.weekly.perfectKeys)?st.weekly.perfectKeys:[];
 return st.weekly;
}
function firebaseConfigured(){const c=window.ECO_FIREBASE_CONFIG||{};return Boolean(c.apiKey&&c.projectId&&c.appId)}
function loginMessage(text){const el=document.getElementById('loginCloudStatus');if(el)el.textContent=text}
function setGoogleButton(disabled,text){const b=document.getElementById('googleLoginBtn');if(b){b.disabled=disabled;if(text)b.textContent=text}}
function setCloudStatus(mode,text){const el=document.getElementById('cloudStatus');if(el){el.className='cloud-status '+mode;el.textContent=text}}
function notifyCloudError(message){
 setCloudStatus('offline',message);
 if(typeof toast==='function')toast(message);
}


function cloudStateTime(state){
 const t=Date.parse(state&&state.savedAt||'');return Number.isFinite(t)?t:0;
}
function applyRemotePlayerSnapshot(data){
 if(!data||!data.state||cloudLoading)return;
 const remote={...defaultState(),...data.state};
 remote.exp=Math.max(Number(remote.exp)||0,Number(data.guardianExp)||0);
 remote.coins=Math.max(Number(remote.coins)||0,Number(data.coins)||0);
 if(data.stageProgress&&typeof data.stageProgress==='object')remote.unitProgress=data.stageProgress;
 const remoteTime=cloudStateTime(remote),localTime=cloudStateTime(st);
 // 只接收真正較新的雲端存檔，避免自己的舊寫入覆蓋剛完成的挑戰。
 if(remoteTime&&remoteTime<=localTime)return;
 const loginState={loggedIn:true,cloudUid:cloudUser&&cloudUser.uid};
 st={...remote,...loginState};
 ensureProgress();ensureProfile();ensureWeeklyLocal();
 try{localStorage.setItem(KEY,JSON.stringify(st));}catch(_e){}
 if(typeof refreshSharedPlayerPanels==='function')refreshSharedPlayerPanels();
 if(typeof renderMap==='function'&&!document.getElementById('mapPage')?.classList.contains('hide'))renderMap();
 if(typeof renderAchievements==='function'&&!document.getElementById('achievementPage')?.classList.contains('hide'))renderAchievements();
 setCloudStatus('online','☁️ 已接收其他裝置的最新進度');
}
function startCloudPlayerListener(){
 if(cloudPlayerUnsubscribe){cloudPlayerUnsubscribe();cloudPlayerUnsubscribe=null;}
 if(!cloudDb||!cloudUser)return;
 cloudPlayerUnsubscribe=playerDoc().onSnapshot(snap=>{
   if(snap.exists)applyRemotePlayerSnapshot(snap.data());
 },err=>console.warn('跨裝置即時同步監聽失敗',err));
}
async function initFirebase(){
 if(!firebaseConfigured()||typeof firebase==='undefined'){loginMessage('Firebase 尚未設定，無法使用 Google 登入。');return;}
 try{
  if(!firebase.apps.length)firebase.initializeApp(window.ECO_FIREBASE_CONFIG);
  cloudAuth=firebase.auth();cloudDb=firebase.firestore();
  await cloudAuth.setPersistence(firebase.auth.Auth.Persistence.LOCAL);
  await cloudAuth.getRedirectResult().catch(()=>null);
  cloudAuth.onAuthStateChanged(async user=>{
   cloudUser=user||null;cloudReady=Boolean(user);
   if(user){setGoogleButton(true,'☁️ 正在載入雲端進度…');await loadCloudPlayer();}
   else{if(cloudPlayerUnsubscribe){cloudPlayerUnsubscribe();cloudPlayerUnsubscribe=null;}cloudIsAdmin=false;updateAdminAccess();setGoogleButton(false,'🟢 使用 Google 開始冒險');loginMessage('使用同一個 Google 帳號，可在不同設備接續進度。');}
  });
 }catch(err){console.error('Firebase 初始化失敗',err);loginMessage('Firebase 初始化失敗，請檢查設定。');setGoogleButton(false,'重新嘗試 Google 登入');}
}
async function googleLogin(){
 if(!cloudAuth){await initFirebase();if(!cloudAuth)return;}
 setGoogleButton(true,'正在開啟 Google 登入…');
 const provider=new firebase.auth.GoogleAuthProvider();provider.setCustomParameters({prompt:'select_account'});
 try{await cloudAuth.signInWithPopup(provider)}catch(err){
  if(['auth/popup-blocked','auth/cancelled-popup-request','auth/operation-not-supported-in-this-environment'].includes(err.code)){
   await cloudAuth.signInWithRedirect(provider);return;
  }
  console.error('Google 登入失敗',err);loginMessage(err.code==='auth/unauthorized-domain'?'此 GitHub 網域尚未加入 Firebase 授權網域。':'Google 登入未完成，請再試一次。');setGoogleButton(false,'🟢 使用 Google 開始冒險');
 }
}
function playerDoc(){return cloudDb.collection('players').doc(cloudUser.uid)}
function weeklyDoc(){return cloudDb.collection('weeklyRankings').doc(currentWeekId()).collection('players').doc(cloudUser.uid)}
function playerFields(includeCreatedAt=false){
 const data={
  uid:cloudUser.uid,
  displayName:cloudUser.displayName||st.name||'',
  photoURL:cloudUser.photoURL||'',
  guardianExp:Number(st.exp)||0,
  coins:Number(st.coins)||0,
  stageProgress:st.unitProgress||st.completed||{},
  totalAnswered:Number(st.totalAnswered)||0,
  todayAnswered:Number(st.todayAnswered)||0,
  todayAnsweredDate:st.todayAnsweredDate||'',
  lastActiveAt:firebase.firestore.FieldValue.serverTimestamp(),
  state:st,
  updatedAt:firebase.firestore.FieldValue.serverTimestamp()
 };
 if(includeCreatedAt)data.createdAt=firebase.firestore.FieldValue.serverTimestamp();
 return data;
}
function weeklyFields(){
 const w=ensureWeeklyLocal(),av=avatarById(st.avatar);
 const totalAnswered=Math.max(0,Number(st.totalAnswered)||0);
 const totalCorrect=Math.max(0,Number(st.totalCorrect)||0);
 const unlockedAchievements=typeof buildAchievementList==='function'?buildAchievementList().filter(a=>a.progress>=a.goal).length:0;
 return {
  uid:cloudUser.uid,
  name:(st.name||cloudUser.displayName||'環保守護者').slice(0,12),
  avatar:av.icon,
  level:currentLevel(),
  title:String(st.specialTitle||'地球守護者').slice(0,16),
  guardianExp:Number(st.exp)||0,
  coins:Number(st.coins)||0,
  badges:typeof S!=='undefined'?S.filter(isDone).length:0,
  streak:Math.max(0,Number(st.streak)||0),
  totalAnswered,
  totalCorrect,
  accuracy:totalAnswered?Math.round(totalCorrect/totalAnswered*100):0,
  achievements:unlockedAchievements,
  points:Number(w.points)||0,
  completedUnits:w.completedKeys.length,
  perfectUnits:w.perfectKeys.length,
  updatedAt:firebase.firestore.FieldValue.serverTimestamp()
 };
}
async function writeWithRetry(label,writeFn,maxAttempts=3){
 let lastError;
 for(let attempt=1;attempt<=maxAttempts;attempt++){
  try{return await writeFn();}
  catch(err){
   lastError=err;console.error(`${label}失敗（第 ${attempt} 次）`,err);
   if(attempt<maxAttempts)await new Promise(resolve=>setTimeout(resolve,500*attempt));
  }
 }
 throw lastError;
}

function activeEventValid(event){
 if(!event||event.active!==true)return false;
 const end=timestampMillis(event.endAt)||Date.parse(event.endDate||'')||0;
 return !end||end>=Date.now();
}
async function loadActiveActivities(){
 if(!cloudDb)return;
 try{
  const snap=await cloudDb.collection('activities').where('active','==',true).get();
  window.ECO_ACTIVE_EVENTS=snap.docs.map(d=>({id:d.id,...d.data()})).filter(activeEventValid);updateHomeAnnouncement();
 }catch(err){console.error('載入活動失敗',err);window.ECO_ACTIVE_EVENTS=[];updateHomeAnnouncement();}
}
async function loadCustomQuestions(){
 if(!cloudDb)return;
 try{
  const snap=await cloudDb.collection('customQuestions').where('active','==',true).limit(300).get();
  window.ECO_CUSTOM_QUESTIONS=snap.docs.map(d=>({docId:d.id,...d.data()}));
 }catch(err){console.error('載入後臺題目失敗',err);window.ECO_CUSTOM_QUESTIONS=[];}
}
window.customQuestionsForUnit=function(stageId,unitNumber){
 return (window.ECO_CUSTOM_QUESTIONS||[]).filter(q=>q.stageId===stageId&&Number(q.unit)===Number(unitNumber)).map(q=>({
   id:`custom_${q.docId}`,level:q.level||'',q:q.q||'',opts:Array.isArray(q.opts)?q.opts.slice(0,4):[],ans:Number(q.ans)||0,exp:q.exp||''
 })).filter(q=>q.q&&q.opts.length===4);
};
window.getActiveExpMultiplier=function(){
 return (window.ECO_ACTIVE_EVENTS||[]).filter(e=>e.type==='doubleExp'&&activeEventValid(e)).reduce((m,e)=>Math.max(m,Number(e.value)||2),1);
};
function updateHomeAnnouncement(){
 const el=document.getElementById('loginState');if(!el)return;
 const notices=(window.ECO_ACTIVE_EVENTS||[]).filter(e=>e.showOnHome!==false&&activeEventValid(e));
 if(!notices.length){el.innerHTML='目前沒有最新活動<small>祝你今天冒險愉快！</small>';el.title='';return;}
 const e=notices[0],end=timestampMillis(e.endAt);el.innerHTML=`${escapeRankText(e.name||'最新活動')}<small>${escapeRankText(e.description||'點擊管理活動查看詳情')}</small>`;el.title=[e.description,end?`至 ${new Date(end).toLocaleDateString('zh-TW')}`:''].filter(Boolean).join('｜');
}
function applyLoginActivityRewards(){
 if(!st.eventClaims||typeof st.eventClaims!=='object')st.eventClaims={};
 const today=typeof localDateKey==='function'?localDateKey():new Date().toISOString().slice(0,10);
 let gained=0;
 (window.ECO_ACTIVE_EVENTS||[]).filter(e=>e.type==='loginCoins'&&activeEventValid(e)).forEach(e=>{
   const key=`${e.id}|${today}`;
   if(!st.eventClaims[key]){const amount=Math.max(0,Number(e.value)||0);st.coins+=amount;gained+=amount;st.eventClaims[key]=true;}
 });
 if(gained&&typeof toast==='function')setTimeout(()=>toast(`🎁 活動每日登入獎勵：+${gained} 金幣`),700);
}

async function checkAccountAccess(){
 try{
  const ref=cloudDb.collection('blockedUsers').doc(cloudUser.uid),snap=await ref.get();
  if(!snap.exists)return {allowed:true};
  const data=snap.data()||{},until=timestampMillis(data.untilAt);
  if(data.status==='deleted')return {allowed:false,message:'此遊戲帳號已由管理者永久刪除。'};
  if(data.status==='suspended'&&(!until||until>Date.now()))return {allowed:false,message:until?`此帳號已停用至 ${new Date(until).toLocaleDateString('zh-TW')}。`:'此帳號已停用，請聯絡管理者。'};
  return {allowed:true};
 }catch(err){
  // 相容尚未發布 V9.3 Firestore Rules 的既有網站：停用名單讀取失敗時，
  // 不應阻斷 players 雲端存檔載入。部署新版 Rules 後停用檢查會自動恢復。
  if(err&&err.code==='permission-denied'){
   console.warn('blockedUsers 權限尚未開放，略過帳號停用檢查。請部署最新版 firestore.rules。',err);
   return {allowed:true,rulesPending:true};
  }
  throw err;
 }
}
async function loadCloudPlayer(){
 if(!cloudReady||cloudLoading)return;cloudLoading=true;
 try{
  const access=await checkAccountAccess();
  if(!access.allowed){loginMessage(access.message);setGoogleButton(false,'帳號目前無法使用');await cloudAuth.signOut();return;}
  const snap=await playerDoc().get();
  const data=snap.exists?snap.data():null;
  cloudIsAdmin=Boolean(data&&data.isAdmin===true);
  updateAdminAccess();
  const localSameUser=st.cloudUid===cloudUser.uid;
  if(data&&data.state){
   const remote={...defaultState(),...data.state};
   const localTime=localSameUser?(Date.parse(st.savedAt||0)||0):0;
   const remoteTime=Date.parse(remote.savedAt||0)||0;
   // 只有同一個 Google UID 才能比較並沿用本機進度，避免不同帳號互相污染。
   st=(localSameUser&&localTime>remoteTime)?{...defaultState(),...st}:remote;
  }else if(data){
   // 相容早期只有頂層欄位、尚未包含完整 state 的玩家文件。
   // 若目前本機資料屬於另一個 UID，先從乾淨狀態建立，不能沿用舊玩家資料。
   const base=localSameUser?{...defaultState(),...st}:defaultState();
   st={...base,exp:Number(data.guardianExp)||0,coins:Number(data.coins)||0,unitProgress:data.stageProgress||base.unitProgress||{}};
  }else{
   // 新 Google 帳號沒有雲端文件時，必須建立獨立的新玩家狀態。
   // 同一台裝置切換帳號時，絕不可把上一個帳號的名稱、進度、金幣與經驗帶過來。
   st=localSameUser?{...defaultState(),...st}:defaultState();
   st.name=(cloudUser.displayName||'環保守護者').slice(0,12);
  }
  st.loggedIn=true;st.cloudUid=cloudUser.uid;
  ensureProgress();ensureProfile();ensureWeeklyLocal();selectedLoginAvatar=st.avatar||'fox';nameInput.value=st.name;
  await Promise.all([loadActiveActivities(),loadCustomQuestions()]);
  dailyLogin();applyLoginActivityRewards();save();enterGame();
  await syncAllCloudData(!snap.exists);
  startCloudPlayerListener();
  await playerDoc().set({lastLoginAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true}).catch(err=>console.error('更新登入時間失敗',err));
  loginMessage(`已登入：${cloudUser.displayName||'Google 使用者'}`);setGoogleButton(false,'✅ 已登入');setCloudStatus('online','☁️ 雲端進度已同步');
 }catch(err){
  console.error('載入雲端存檔失敗',err);loginMessage('雲端存檔載入失敗，已保留本機資料，可稍後重試。');setGoogleButton(false,'重新嘗試 Google 登入');notifyCloudError('⚠️ 雲端載入失敗，遊戲仍可繼續');
 }finally{cloudLoading=false}
}
function scheduleCloudSave(){
 if(!cloudReady||cloudLoading||!st.loggedIn)return;
 clearTimeout(cloudSaveTimer);cloudSaveTimer=setTimeout(()=>syncAllCloudData(false),350);
}
async function syncAllCloudData(isNewPlayer=false){
 if(!cloudReady||!cloudDb||!cloudUser||!st.loggedIn)return;
 if(cloudWriteInProgress){cloudWriteQueued=true;return;}
 cloudWriteInProgress=true;clearTimeout(cloudRetryTimer);
 try{
  await writeWithRetry('玩家雲端存檔',()=>playerDoc().set(playerFields(isNewPlayer),{merge:true}));
  await writeWithRetry('排行榜資料同步',()=>weeklyDoc().set(weeklyFields(),{merge:true}));
  schedulePublicBaseSync();
  setCloudStatus('online','☁️ 雲端進度與基地已同步');
 }catch(err){
  console.error('Firestore 同步最終失敗',err);notifyCloudError('⚠️ 雲端同步失敗，資料已保留在本機');
  cloudRetryTimer=setTimeout(()=>syncAllCloudData(false),5000);
 }finally{
  cloudWriteInProgress=false;
  if(cloudWriteQueued){cloudWriteQueued=false;scheduleCloudSave();}
 }
}
async function saveCloudNow(){return syncAllCloudData(false)}
async function syncWeeklyProfile(){return syncAllCloudData(false)}
async function addWeeklyQuestionPoints(amount){
 const add=Number(amount)||0;if(add<=0)return;
 const w=ensureWeeklyLocal();w.points=(Number(w.points)||0)+add;save();
}
async function recordWeeklyUnitProgress(stageId,unitIndex,first,firstPerfect){
 const w=ensureWeeklyLocal(),key=`${stageId}|${unitIndex}`;let changed=false;
 if(first&&!w.completedKeys.includes(key)){w.completedKeys.push(key);changed=true;}
 if(firstPerfect&&!w.perfectKeys.includes(key)){w.perfectKeys.push(key);changed=true;}
 if(changed)save();
}
function timestampMillis(value){
 if(!value)return 0;
 if(typeof value.toMillis==='function')return value.toMillis();
 if(value.seconds)return Number(value.seconds)*1000;
 return Date.parse(value)||0;
}
let leaderboardRowsCache=[];
let activeRankingMode='weekly';
function switchRankingMode(mode,button){
 activeRankingMode=mode==='total'?'total':'weekly';
 document.querySelectorAll('.ranking-tabs button').forEach(x=>x.classList.remove('active'));
 if(button)button.classList.add('active');
 refreshLeaderboard(activeRankingMode);
}
function normalizeTotalRankingRow(doc){
 const x=doc.data?doc.data():doc||{},state=x.state||{};
 const totalAnswered=Math.max(0,Number(x.totalAnswered??state.totalAnswered)||0);
 const totalCorrect=Math.max(0,Number(x.totalCorrect??state.totalCorrect)||0);
 const avatarData=typeof avatarById==='function'?avatarById(state.avatar||'fox'):null;
 return {
  uid:x.uid||doc.id||'',
  name:(state.name||x.displayName||'環保守護者').slice(0,12),
  avatar:(avatarData&&avatarData.icon)||state.avatar||'🌱',
  level:typeof levelFromExp==='function'?levelFromExp(Number(x.guardianExp??state.exp)||0):1,
  title:String(state.specialTitle||'地球守護者').slice(0,16),
  guardianExp:Number(x.guardianExp??state.exp)||0,
  coins:Number(x.coins??state.coins)||0,
  badges:typeof S!=='undefined'&&state.completed?S.filter(stage=>new Set(state.completed[stage.id]||[]).size>=unitCount(stage.id)).length:0,
  streak:Math.max(0,Number(state.streak)||0),
  totalAnswered,totalCorrect,
  accuracy:totalAnswered?Math.round(totalCorrect/totalAnswered*100):0,
  achievements:0,
  completedUnits:Object.values(state.completed||{}).reduce((n,a)=>n+(Array.isArray(a)?a.length:0),0),
  perfectUnits:0,
  updatedAt:x.updatedAt||x.lastActiveAt
 };
}
async function ensureRankingCloudReady(timeoutMs=5000){
  if(cloudReady&&cloudDb&&cloudUser)return true;
  if(typeof firebase==='undefined'||!firebaseConfigured())return false;
  const started=Date.now();
  while(Date.now()-started<timeoutMs){
    const user=cloudAuth?.currentUser||firebase.auth?.().currentUser;
    if(user&&cloudDb){cloudUser=user;cloudReady=true;return true;}
    await new Promise(resolve=>setTimeout(resolve,180));
  }
  return Boolean(cloudReady&&cloudDb&&cloudUser);
}
async function rankingGetWithRetry(makeQuery,maxAttempts=3){
  let lastError;
  for(let i=1;i<=maxAttempts;i++){
    try{return await makeQuery().get({source:'server'});}
    catch(err){
      lastError=err;
      // iPad/Safari 從背景恢復時，Firestore 可能短暫回報 unavailable；重新啟用網路後重試。
      if(cloudDb&&['unavailable','failed-precondition','deadline-exceeded','unknown'].includes(err?.code||'')){
        try{await cloudDb.enableNetwork();}catch(_e){}
      }
      if(i<maxAttempts)await new Promise(resolve=>setTimeout(resolve,450*i));
    }
  }
  throw lastError;
}
async function refreshLeaderboard(mode=activeRankingMode){
 activeRankingMode=mode==='total'?'total':'weekly';
 ensureWeeklyLocal();
 const isWeekly=activeRankingMode==='weekly';
 const label=document.getElementById('weekLabel'),pts=document.getElementById('myWeeklyPoints'),rank=document.getElementById('myWeeklyRank'),list=document.getElementById('leaderboardList');
 const title=document.getElementById('rankingTitle'),desc=document.getElementById('rankingDescription'),eyebrow=document.getElementById('rankingEyebrow');
 const pointsLabel=document.getElementById('myRankingPointsLabel'),rankLabel=document.getElementById('myRankingRankLabel');
 if(title)title.textContent=isWeekly?'🥇 每週守護者排行榜':'🏆 守護者總排行榜';
 if(desc)desc.textContent=isWeekly?'每週一 00:00 起算、星期日 23:59 結算，依本週積分由高到低排名。':'依累計守護經驗由高到低排名，長期累積不歸零。';
 if(eyebrow)eyebrow.textContent=isWeekly?'WEEKLY GUARDIAN RANKING':'ALL-TIME GUARDIAN RANKING';
 if(pointsLabel)pointsLabel.textContent=isWeekly?'我的本週積分':'我的累計守護經驗';
 if(rankLabel)rankLabel.textContent=isWeekly?'我的每週名次':'我的總排行名次';
 if(label)label.textContent=isWeekly?weekDateRange():'累計至今';
 if(pts)pts.textContent=(isWeekly?Number(st.weekly?.points||0):Number(st.exp||0)).toLocaleString('zh-TW');
 if(!list)return;
 if(!(await ensureRankingCloudReady())){if(rank)rank.textContent='—';list.innerHTML='<div class="empty-ranking">請先使用 Google 登入，才能查看共同排行榜。</div>';setCloudStatus('waiting','☁️ 等待 Google 登入狀態…');return;}
 try{
  let rows=[];
  if(isWeekly){
   const snap=await rankingGetWithRetry(()=>cloudDb.collection('weeklyRankings').doc(currentWeekId()).collection('players').limit(500));
   const rawRows=snap.docs.map(d=>({id:d.id,...d.data()}));
   // 舊版週榜可能只有 guardianExp、沒有 points；統一換算後再去除重複玩家。
   const merged=new Map();
   rawRows.forEach(row=>{
    const score=Number.isFinite(Number(row.points))?Number(row.points):(Number(row.guardianExp)||0);
    const key=String(row.uid||row.id||row.name||'').trim().toLowerCase();
    const normalized={...row,points:Math.max(0,score)};
    const previous=merged.get(key);
    if(!previous||normalized.points>previous.points||(normalized.points===previous.points&&timestampMillis(normalized.updatedAt)>timestampMillis(previous.updatedAt)))merged.set(key,normalized);
   });
   rows=[...merged.values()].sort((a,b)=>{
    const diff=(Number(b.points)||0)-(Number(a.points)||0);
    return diff||timestampMillis(a.updatedAt)-timestampMillis(b.updatedAt)||String(a.name||'').localeCompare(String(b.name||''),'zh-Hant');
   });
  }else{
   const snap=await rankingGetWithRetry(()=>cloudDb.collection('players').limit(500));
   rows=snap.docs.map(normalizeTotalRankingRow).sort((a,b)=>{
    const diff=(Number(b.guardianExp)||0)-(Number(a.guardianExp)||0);
    return diff||timestampMillis(b.updatedAt)-timestampMillis(a.updatedAt);
   });
  }
  leaderboardRowsCache=rows;
  if(!rows.length){list.innerHTML=`<div class="empty-ranking">${isWeekly?'本週':'目前'}還沒有排名紀錄。</div>`;if(rank)rank.textContent='—';return;}
  const myIndex=rows.findIndex(x=>x.uid===cloudUser.uid);
  if(isWeekly&&myIndex>=0){const currentRank=myIndex+1;if(!st.bestWeeklyRank||currentRank<st.bestWeeklyRank){st.bestWeeklyRank=currentRank;save();}}
  if(rank)rank.textContent=myIndex>=0?`第 ${myIndex+1} 名`:'500 名以外';list.innerHTML='';
  rows.forEach((x,i)=>{
   const canViewAnalysis=cloudIsAdmin||x.uid===cloudUser.uid;
   const row=document.createElement(canViewAnalysis?'button':'div');
   if(canViewAnalysis)row.type='button';
   row.className='rank-row'+(canViewAnalysis?' rank-row-button':' rank-row-private')+(x.uid===cloudUser.uid?' me':'');
   if(canViewAnalysis)row.setAttribute('aria-label',cloudIsAdmin&&x.uid!==cloudUser.uid?`以管理員身分查看 ${x.name||'環保守護者'} 的分析`:'查看我的學習分析');
   const medal=i===0?'🥇':i===1?'🥈':i===2?'🥉':String(i+1);const score=isWeekly?Number(x.points||0):Number(x.guardianExp||0);const scoreLabel=isWeekly?'本週積分':'守護經驗';
   row.innerHTML=`<div class="rank-no">${medal}</div><div class="rank-player"><span class="rank-avatar">${String(x.avatar||'🌱').includes('/')?`<img class="guardian-avatar-img" src="${x.avatar}" alt="守護者">`:(x.avatar||'🌱')}</span><div><b>${escapeRankText(x.name||'環保守護者')}</b><small>Lv.${Number(x.level)||1}・完成 ${Number(x.completedUnits)||0} 單元</small></div></div><div class="rank-points"><b>${score.toLocaleString('zh-TW')}</b><small>${scoreLabel}</small></div>${canViewAnalysis?`<span class="rank-open">${cloudIsAdmin&&x.uid!==cloudUser.uid?'管理員查看分析':'我的分析'} ›</span>`:'<span class="rank-open rank-private-label">分析不公開</span>'}`;
   if(canViewAnalysis)row.addEventListener('click',()=>openRankProfile(i));
   list.appendChild(row);
  });
  setCloudStatus('online',`☁️ ${isWeekly?'每週':'總'}排行榜已更新`);
 }catch(err){console.error('讀取排行榜失敗',err);const trulyOffline=navigator.onLine===false;list.innerHTML=`<div class="empty-ranking">${trulyOffline?'目前沒有網路連線。':'雲端排行榜暫時忙碌，請按「更新排行」再試一次。'}</div>`;setCloudStatus(trulyOffline?'offline':'waiting',trulyOffline?'⚠️ 目前離線':'☁️ 雲端連線中，請稍後重試');}
}
function rankClamp(value){return Math.max(0,Math.min(100,Number(value)||0))}
function rankMetric(label,value,icon){return `<div class="rank-data-item"><span>${icon}</span><small>${label}</small><b>${escapeRankText(value)}</b></div>`}
function rankBar(label,value,detail){const pct=rankClamp(value);return `<div class="rank-analysis-row"><div><b>${label}</b><small>${detail}</small></div><div class="rank-analysis-track"><i style="width:${pct}%"></i></div><strong>${Math.round(pct)}</strong></div>`}
function openRankProfile(index,options={}){
 const x=options.player||leaderboardRowsCache[index];if(!x)return;
 const isOwn=Boolean(cloudUser&&x.uid===cloudUser.uid);
 if(!cloudIsAdmin&&!isOwn){toast('基於資料隱私，只能查看自己的學習分析');return;}
 const analysisMode=options.mode||activeRankingMode;
 const modal=document.getElementById('rankProfileModal'),content=document.getElementById('rankProfileContent');if(!modal||!content)return;
 const rank=Number(options.rank)||index+1,totalAnswered=Math.max(0,Number(x.totalAnswered)||0),totalCorrect=Math.max(0,Number(x.totalCorrect)||0);
 const accuracy=Number.isFinite(Number(x.accuracy))?Number(x.accuracy):(totalAnswered?Math.round(totalCorrect/totalAnswered*100):0);
 const completed=Math.max(0,Number(x.completedUnits)||0),perfect=Math.max(0,Number(x.perfectUnits)||0),streak=Math.max(0,Number(x.streak)||0),ach=Math.max(0,Number(x.achievements)||0),badges=Math.max(0,Number(x.badges)||0);
 const activityScore=rankClamp(totalAnswered/5),accuracyScore=rankClamp(accuracy),completionScore=rankClamp(completed/0.4),perfectScore=rankClamp(perfect*12.5),streakScore=rankClamp(streak*7),achievementScore=rankClamp(ach/0.15);
 const strongest=[['答題活躍',activityScore],['答題正確',accuracyScore],['關卡完成',completionScore],['滿分挑戰',perfectScore],['持續登入',streakScore],['成就收藏',achievementScore]].sort((a,b)=>b[1]-a[1]);
 const praise=strongest[0][1]>=70?`${strongest[0][0]}表現最亮眼`:'正在穩定累積守護力量';
 const improve=strongest[strongest.length-1][1]<55?`下一步可加強「${strongest[strongest.length-1][0]}」`:'各項能力發展相當均衡';
 const avatar=String(x.avatar||'🌱').includes('/')?`<img class="guardian-avatar-img rank-profile-avatar-img" src="${x.avatar}" alt="守護者">`:(x.avatar||'🌱');
 content.innerHTML=`<header class="rank-profile-head"><div class="rank-profile-avatar">${avatar}</div><div><small>${analysisMode==='weekly'?'MY WEEKLY ANALYSIS':cloudIsAdmin&&!isOwn?'ADMIN PLAYER ANALYSIS':'MY LEARNING ANALYSIS'}</small><h2 id="rankProfileTitle">${escapeRankText(x.name||'環保守護者')}</h2><p>${escapeRankText(x.title||'地球守護者')}・Lv.${Number(x.level)||1}・${analysisMode==='weekly'?'本週':'總排行'}第 ${rank} 名</p></div><div class="rank-profile-rank">#${rank}</div></header>
 <section class="rank-data-grid">${rankMetric('守護經驗',Number(x.guardianExp||0).toLocaleString('zh-TW'),'⭐')}${rankMetric('守護金幣',Number(x.coins||0).toLocaleString('zh-TW'),'🪙')}${rankMetric('榮耀徽章',`${badges} 枚`,'🏅')}${rankMetric('連續登入',`${streak} 天`,'🔥')}${rankMetric('累計答題',`${totalAnswered} 題`,'📝')}${rankMetric('答題正確率',`${Math.round(accuracy)}%`,'🎯')}${rankMetric('完成單元',`${completed} 個`,'🗺️')}${rankMetric('解鎖成就',`${ach} 個`,'🏆')}</section>
 <section class="rank-analysis-card"><div class="rank-section-title"><div><small>PLAYER ANALYSIS</small><h3>📊 ${cloudIsAdmin&&!isOwn?'玩家學習分析':'我的學習分析'}</h3></div><span>${cloudIsAdmin&&!isOwn?'管理員權限':'僅自己可見'}</span></div>
 ${rankBar('答題活躍',activityScore,`${totalAnswered} 題累計作答`)}${rankBar('答題正確',accuracyScore,`${Math.round(accuracy)}% 正確率`)}${rankBar('關卡完成',completionScore,`${completed} 個本週完成單元`)}${rankBar('滿分挑戰',perfectScore,`${perfect} 個滿分單元`)}${rankBar('持續登入',streakScore,`${streak} 天連續登入`)}${rankBar('成就收藏',achievementScore,`${ach} 個已解鎖成就`)}</section>
 <section class="rank-report"><b>🌟 守護分析報告</b><p>${praise}，${improve}。這份分析僅供本人查看；管理員因維護與輔導需要可查看所有玩家資料。排行榜本身不顯示 Email、UID、學校、班級或個別答題內容。</p></section>`;
 modal.classList.remove('hide');document.body.classList.add('modal-open');modal.querySelector('.rank-profile-close')?.focus();
}
function closeRankProfile(event){if(event&&event.target!==event.currentTarget)return;const modal=document.getElementById('rankProfileModal');if(modal)modal.classList.add('hide');document.body.classList.remove('modal-open')}
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeRankProfile()});
function escapeRankText(v){const d=document.createElement('div');d.textContent=String(v);return d.innerHTML}
function showLeaderboard(){page('leaderboardPage');refreshLeaderboard()}
const _v80finish=finish;finish=function(){ensureProgress();const wasFirst=!doneSet(stage.id).has(unit),wasFirstPerfect=score===quiz.length&&!((st.coinAwarded||{})[`${stage.id}|${unit}`]),sid=stage.id,ui=unit;_v80finish();recordWeeklyUnitProgress(sid,ui,wasFirst,wasFirstPerfect)};
const _v80profile=saveProfileName;saveProfileName=function(){_v80profile();saveCloudNow()};
const _v80avatar=chooseAvatar;chooseAvatar=function(id){_v80avatar(id);saveCloudNow()};
async function logout(){
 await saveCloudNow();st.loggedIn=false;save();logoutModal.classList.add('hide');game.classList.add('hide');loginPage.classList.remove('hide');
 cloudIsAdmin=false;updateAdminAccess();if(cloudAuth)await cloudAuth.signOut();setGoogleButton(false,'🟢 使用 Google 開始冒險');
}
function updateAdminAccess(){
 const btn=document.getElementById('adminNavBtn');
 if(btn)btn.classList.toggle('hide',!cloudIsAdmin);
 if(!cloudIsAdmin&&!document.getElementById('adminPage')?.classList.contains('hide'))showMap();
}
function adminDate(value){
 const ms=timestampMillis(value);return ms?new Date(ms).toLocaleString('zh-TW'):'—';
}
function todayStart(){const d=new Date();d.setHours(0,0,0,0);return d.getTime()}
function switchAdminTab(name,button){
 document.querySelectorAll('.admin-panel').forEach(x=>x.classList.add('hide'));
 const panel=document.getElementById('adminTab'+name.charAt(0).toUpperCase()+name.slice(1));if(panel)panel.classList.remove('hide');
 document.querySelectorAll('.admin-tabs button').forEach(x=>x.classList.remove('active'));if(button)button.classList.add('active');
 if(name==='players')loadAdminPlayers();if(name==='questions')loadAdminQuestions();if(name==='events')loadAdminEvents();if(name==='ranking')loadAdminRanking();
}
async function showAdminDashboard(){
 if(!cloudIsAdmin){toast('此帳號沒有管理者權限');return;}
 page('adminPage');await loadAdminDashboard();
}
async function loadAdminDashboard(){
 if(!cloudDb||!cloudIsAdmin)return;
 try{
  await loadAdminPlayers(false);
  const rows=adminPlayersCache,now=Date.now(),today=todayStart(),weekAgo=now-7*86400000;
  const totalExp=rows.reduce((n,x)=>n+(Number(x.guardianExp)||0),0);
  const totalCoins=rows.reduce((n,x)=>n+(Number(x.coins)||0),0);
  const totalAnswered=rows.reduce((n,x)=>n+(Number(x.totalAnswered??x.state?.totalAnswered)||0),0);
  const todayAnswered=rows.reduce((n,x)=>n+((x.todayAnsweredDate===new Date().toISOString().slice(0,10))?(Number(x.todayAnswered)||0):0),0);
  const todayLogins=rows.filter(x=>timestampMillis(x.lastLoginAt)>=today).length;
  const active=rows.filter(x=>timestampMillis(x.lastActiveAt||x.updatedAt)>=weekAgo).length;
  const summary=document.getElementById('adminSummary');
  summary.innerHTML=[
   ['玩家總數',rows.length],['今日登入',todayLogins],['活躍玩家（7天）',active],
   ['全站經驗值',totalExp],['全站金幣',totalCoins],['題目作答數',totalAnswered],['今日答題數',todayAnswered]
  ].map(x=>`<div><small>${x[0]}</small><b>${x[1]}</b></div>`).join('');
  await Promise.all([loadAdminQuestions(false),loadAdminEvents(false),loadAdminRanking(false)]);
 }catch(err){console.error('管理後臺載入失敗',err);document.getElementById('adminSummary').innerHTML='<div class="empty-ranking">無法讀取管理資料，請先部署 V9.2 firestore.rules。</div>';}
}
async function loadAdminPlayers(render=true){
 if(!cloudDb||!cloudIsAdmin)return;
 const snap=await cloudDb.collection('players').limit(500).get();
 adminPlayersCache=snap.docs.map(d=>({uid:d.id,...d.data()})).sort((a,b)=>(Number(b.guardianExp)||0)-(Number(a.guardianExp)||0));
 if(render)renderAdminPlayers();
}
function renderAdminPlayers(){
 const list=document.getElementById('adminPlayerList');if(!list)return;
 const key=(document.getElementById('adminPlayerSearch')?.value||'').trim().toLowerCase();
 const rows=adminPlayersCache.filter(x=>`${x.displayName||x.state?.name||''} ${x.uid}`.toLowerCase().includes(key));
 list.innerHTML=rows.length?'':'<div class="empty-ranking">找不到符合的玩家。</div>';
 rows.forEach(x=>{
  const row=document.createElement('div');row.className='admin-player-editor';
  row.innerHTML=`<div class="admin-player-name"><strong>${escapeRankText(x.displayName||x.state?.name||'未命名玩家')}</strong><small>${escapeRankText(x.uid)}</small></div>
   <label>金幣<input type="number" min="0" data-field="coins" value="${Number(x.coins)||0}"></label>
   <label>經驗值<input type="number" min="0" data-field="guardianExp" value="${Number(x.guardianExp)||0}"></label>
   <label>關卡進度<select data-field="stage"><option value="">保持目前</option><option value="s1">完成 Stage 1</option><option value="s2">完成至 Stage 2</option><option value="s3">完成至 Stage 3</option><option value="s4">完成全部 Stage</option><option value="reset">重設關卡進度</option></select></label>
   <label class="admin-check"><input type="checkbox" data-field="isAdmin" ${x.isAdmin===true?'checked':''}> 管理員</label>
   <div class="admin-player-actions"><button class="secondary" onclick="openAdminPlayerAnalysis('${x.uid}')">📊 查看分析</button><button class="primary" onclick="adminSavePlayer('${x.uid}',this)">儲存</button><button class="secondary" onclick="adminResetPlayer('${x.uid}')">重設遊戲紀錄</button><button class="warning" onclick="adminSuspendPlayer('${x.uid}')">停用帳號</button><button class="danger" onclick="adminDeletePlayer('${x.uid}')">永久刪除</button></div>`;
  list.appendChild(row);
 });
}
function completedStateThrough(stageId,state){
 const next={...state,completed:{...(state.completed||{})},unitProgress:{...(state.unitProgress||{})},unitScores:{...(state.unitScores||{})}};
 if(stageId==='reset'){next.completed={};next.unitProgress={};next.unitScores={};return next;}
 const max=S.findIndex(s=>s.id===stageId);
 S.forEach((s,i)=>{if(i<=max){const count=unitCount(s.id);next.completed[s.id]=Array.from({length:count},(_,n)=>n);next.unitProgress[s.id]=Array(count).fill(10);next.unitScores[s.id]=Array(count).fill(10);}});
 return next;
}
function openAdminPlayerAnalysis(uid){
 if(!cloudIsAdmin){toast('此帳號沒有管理者權限');return;}
 const original=adminPlayersCache.find(x=>x.uid===uid);if(!original){toast('找不到玩家資料');return;}
 const player=normalizeTotalRankingRow({id:uid,data:()=>original});
 const sorted=[...adminPlayersCache].sort((a,b)=>(Number(b.guardianExp)||0)-(Number(a.guardianExp)||0));
 const rank=Math.max(1,sorted.findIndex(x=>x.uid===uid)+1);
 openRankProfile(0,{player,rank,mode:'total'});
}
async function adminSavePlayer(uid,button){
 const row=button.closest('.admin-player-editor'),coins=Math.max(0,Number(row.querySelector('[data-field="coins"]').value)||0),exp=Math.max(0,Number(row.querySelector('[data-field="guardianExp"]').value)||0);
 const stageValue=row.querySelector('[data-field="stage"]').value,isAdminValue=row.querySelector('[data-field="isAdmin"]').checked;
 const original=adminPlayersCache.find(x=>x.uid===uid)||{},state={...(original.state||{})};
 state.coins=coins;state.exp=exp;if(stageValue)Object.assign(state,completedStateThrough(stageValue,state));
 button.disabled=true;
 try{await cloudDb.collection('players').doc(uid).set({coins,guardianExp:exp,stageProgress:state.unitProgress||{},state,isAdmin:isAdminValue,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});toast('玩家資料已更新');await loadAdminPlayers();}
 catch(err){console.error('更新玩家失敗',err);toast('更新失敗，請檢查 Firestore Rules');}
 finally{button.disabled=false;}
}
async function adminResetPlayer(uid){
 if(uid===cloudUser.uid&&!confirm('你正在重設自己的管理者遊戲紀錄，管理權限會保留。確定繼續？'))return;
 if(!confirm('確定重設此玩家的金幣、經驗、關卡、基地、怪獸圖鑑與登入紀錄？'))return;
 const original=adminPlayersCache.find(x=>x.uid===uid)||{},fresh=defaultState();fresh.name=original.displayName||original.state?.name||'環保守護者';fresh.cloudUid=uid;
 try{await cloudDb.collection('players').doc(uid).set({guardianExp:0,coins:0,stageProgress:{},totalAnswered:0,todayAnswered:0,todayAnsweredDate:'',state:fresh,isAdmin:original.isAdmin===true,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});await cloudDb.collection('weeklyRankings').doc(currentWeekId()).collection('players').doc(uid).delete().catch(()=>{});toast('玩家遊戲紀錄已重設');await loadAdminPlayers();}catch(err){console.error(err);toast('重設失敗');}
}
async function adminSuspendPlayer(uid){
 if(uid===cloudUser.uid){toast('不能停用目前登入的管理者帳號');return;}
 const input=prompt('輸入停用天數；留白代表不限期停用。輸入 0 可解除停用。','7');if(input===null)return;
 const days=input.trim()===''?null:Number(input);if(days!==null&&(!Number.isFinite(days)||days<0)){toast('請輸入 0 以上的天數');return;}
 try{const ref=cloudDb.collection('blockedUsers').doc(uid);if(days===0)await ref.delete();else await ref.set({uid,status:'suspended',untilAt:days===null?null:firebase.firestore.Timestamp.fromDate(new Date(Date.now()+days*86400000)),updatedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedBy:cloudUser.uid});toast(days===0?'已解除停用':days===null?'已不限期停用':'已停用 '+days+' 天');}catch(err){console.error(err);toast('停用設定失敗');}
}
async function adminDeletePlayer(uid){
 if(uid===cloudUser.uid){toast('不能刪除目前登入的管理者帳號');return;}
 const text=prompt('永久刪除會清除遊戲存檔並阻止再次進入。請輸入 DELETE 確認：');if(text!=='DELETE')return;
 try{await cloudDb.collection('blockedUsers').doc(uid).set({uid,status:'deleted',updatedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedBy:cloudUser.uid});await cloudDb.collection('players').doc(uid).delete();await cloudDb.collection('weeklyRankings').doc(currentWeekId()).collection('players').doc(uid).delete().catch(()=>{});toast('遊戲帳號及主要紀錄已永久刪除');await loadAdminPlayers();}catch(err){console.error(err);toast('刪除失敗');}
}
async function saveAdminQuestion(event){
 event.preventDefault();
 const stageId=adminQuestionStage.value,unit=Number(adminQuestionUnit.value),max=unitCount(stageId);
 if(unit<1||unit>max){toast(`此 Stage 的單元範圍是 1～${max}`);return;}
 const data={stageId,unit,level:adminQuestionLevel.value,q:adminQuestionText.value.trim(),opts:[adminOption0.value.trim(),adminOption1.value.trim(),adminOption2.value.trim(),adminOption3.value.trim()],ans:Number(adminQuestionAnswer.value),exp:adminQuestionExplanation.value.trim(),active:true,createdAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()};
 try{await cloudDb.collection('customQuestions').add(data);event.target.reset();adminQuestionUnit.value=1;toast('題目已新增');await loadAdminQuestions();await loadCustomQuestions();}
 catch(err){console.error('新增題目失敗',err);toast('新增題目失敗');}
}
function parseCsvLine(line){const out=[];let cur='',quoted=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'){if(quoted&&line[i+1]==='"'){cur+='"';i++;}else quoted=!quoted;}else if(c===','&&!quoted){out.push(cur);cur='';}else cur+=c;}out.push(cur);return out;}
function normalizeImportedQuestion(r){const opts=r.opts||[r.A,r.B,r.C,r.D];let ans=r.ans??r.answer??0;if(typeof ans==='string'&&/^[ABCD]$/i.test(ans))ans='ABCD'.indexOf(ans.toUpperCase());return {stageId:String(r.stageId||r.stage||'s1').toLowerCase().replace('stage','s'),unit:Number(r.unit)||1,level:r.level||'初級',q:r.q||r.question||'',opts:Array.isArray(opts)?opts.slice(0,4):[],ans:Number(ans)||0,exp:r.exp||r.explanation||'',active:true};}
async function adminImportQuestions(event){
 const file=event.target.files?.[0];if(!file)return;
 try{
  const text=await file.text();let rows;
  if(file.name.toLowerCase().endsWith('.json')){const parsed=JSON.parse(text);rows=Array.isArray(parsed)?parsed:parsed.questions;}
  else{const lines=text.replace(/^\ufeff/,'').split(/\r?\n/).filter(Boolean),heads=parseCsvLine(lines.shift()).map(x=>x.trim());rows=lines.map(line=>Object.fromEntries(parseCsvLine(line).map((v,i)=>[heads[i],v])));}
  rows=(rows||[]).map(normalizeImportedQuestion).filter(q=>q.q&&q.opts.length===4&&['s1','s2','s3','s4'].includes(q.stageId));
  if(!rows.length)throw new Error('沒有可匯入題目');if(!confirm(`確認匯入 ${rows.length} 題？`))return;
  for(let i=0;i<rows.length;i+=400){const batch=cloudDb.batch();rows.slice(i,i+400).forEach(q=>{const ref=cloudDb.collection('customQuestions').doc();batch.set(ref,{...q,createdAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});});await batch.commit();}
  toast(`已匯入 ${rows.length} 題`);await loadAdminQuestions();await loadCustomQuestions();
 }catch(err){console.error(err);toast('匯入失敗：請檢查檔案格式');}finally{event.target.value='';}
}
function downloadQuestionImportTemplate(){
 const csv='\ufeffstageId,unit,level,q,A,B,C,D,ans,exp\r\ns1,1,初級,下列哪一項最環保？,自備水壺,每天買瓶裝水,亂丟垃圾,浪費紙張,A,自備水壺可減少一次性垃圾';
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='環保冒險王_題庫匯入範本.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
async function loadAdminQuestions(render=true){
 if(!cloudDb||!cloudIsAdmin)return;
 const snap=await cloudDb.collection('customQuestions').limit(300).get();adminQuestionsCache=snap.docs.map(d=>({id:d.id,...d.data()}));
 if(render)renderAdminQuestions();
}
function renderAdminQuestions(){
 const list=document.getElementById('adminQuestionList');if(!list)return;
 list.innerHTML=adminQuestionsCache.length?'':'<div class="empty-ranking">尚未新增後臺題目。</div>';
 adminQuestionsCache.forEach(q=>{const d=document.createElement('div');d.className='admin-data-card';d.innerHTML=`<div><b>${escapeRankText(q.q)}</b><small>${q.stageId.toUpperCase()}・單元 ${q.unit}・${q.level||''}</small></div><label class="admin-check"><input type="checkbox" ${q.active!==false?'checked':''} onchange="adminToggleDoc('customQuestions','${q.id}',this.checked)"> 啟用</label><button class="danger small" onclick="adminDeleteDoc('customQuestions','${q.id}','題目')">刪除</button>`;list.appendChild(d);});
}
async function saveAdminEvent(event){
 event.preventDefault();const end=adminEventEnd.value?new Date(adminEventEnd.value+'T23:59:59'):null;
 const data={name:adminEventName.value.trim(),type:adminEventType.value,value:Number(adminEventValue.value)||0,description:adminEventDescription.value.trim(),showOnHome:adminEventShowHome.checked,active:true,endAt:end?firebase.firestore.Timestamp.fromDate(end):null,updatedAt:firebase.firestore.FieldValue.serverTimestamp()};
 try{if(adminEditingEventId)await cloudDb.collection('activities').doc(adminEditingEventId).update(data);else await cloudDb.collection('activities').add({...data,createdAt:firebase.firestore.FieldValue.serverTimestamp()});toast(adminEditingEventId?'活動已修改':'活動已建立');cancelAdminEventEdit();await loadAdminEvents();await loadActiveActivities();}
 catch(err){console.error('儲存活動失敗',err);toast('儲存活動失敗');}
}
function editAdminEvent(id){const e=adminEventsCache.find(x=>x.id===id);if(!e)return;adminEditingEventId=id;adminEventName.value=e.name||'';adminEventType.value=e.type||'notice';adminEventValue.value=Number(e.value)||0;adminEventDescription.value=e.description||'';adminEventShowHome.checked=e.showOnHome!==false;const ms=timestampMillis(e.endAt);adminEventEnd.value=ms?new Date(ms-new Date(ms).getTimezoneOffset()*60000).toISOString().slice(0,10):'';adminEventFormTitle.textContent='修改活動';adminEventSubmitBtn.textContent='💾 儲存修改';adminEventCancelEdit.classList.remove('hide');adminEventForm.scrollIntoView({behavior:'smooth'});}
function cancelAdminEventEdit(){adminEditingEventId=null;const form=document.getElementById('adminEventForm');if(form)form.reset();adminEventValue.value=2;adminEventShowHome.checked=true;adminEventFormTitle.textContent='建立活動';adminEventSubmitBtn.textContent='＋ 建立活動';adminEventCancelEdit.classList.add('hide');}
async function loadAdminEvents(render=true){if(!cloudDb||!cloudIsAdmin)return;const snap=await cloudDb.collection('activities').limit(100).get();adminEventsCache=snap.docs.map(d=>({id:d.id,...d.data()}));if(render)renderAdminEvents();}
function renderAdminEvents(){const list=document.getElementById('adminEventList');if(!list)return;list.innerHTML=adminEventsCache.length?'':'<div class="empty-ranking">目前沒有活動。</div>';adminEventsCache.forEach(e=>{const d=document.createElement('div');d.className='admin-data-card';d.innerHTML=`<div><b>${escapeRankText(e.name||'未命名活動')}</b><small>${escapeRankText(e.type)}・數值 ${Number(e.value)||0}・結束 ${adminDate(e.endAt)}</small><p>${escapeRankText(e.description||'')}</p></div><span class="status-pill ${e.active===true?'active':'paused'}">${e.active===true?'進行中':'已暫停'}</span><button class="secondary small" onclick="editAdminEvent('${e.id}')">修改</button><button class="warning small" onclick="adminToggleDoc('activities','${e.id}',${e.active===true?'false':'true'})">${e.active===true?'暫停':'恢復'}</button><button class="danger small" onclick="adminDeleteDoc('activities','${e.id}','活動')">刪除</button>`;list.appendChild(d);});}
async function adminToggleDoc(collection,id,active){try{await cloudDb.collection(collection).doc(id).update({active,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});toast(active?'已啟用':'已停用');if(collection==='activities')await loadActiveActivities();else await loadCustomQuestions();}catch(err){console.error(err);toast('更新失敗');}}
async function adminDeleteDoc(collection,id,label){if(!confirm(`確定刪除這個${label}？`))return;try{await cloudDb.collection(collection).doc(id).delete();toast(`${label}已刪除`);collection==='activities'?await loadAdminEvents():await loadAdminQuestions();}catch(err){console.error(err);toast('刪除失敗');}}
async function loadAdminRanking(render=true){
 if(!cloudDb||!cloudIsAdmin)return;const snap=await cloudDb.collection('weeklyRankings').doc(currentWeekId()).collection('players').limit(500).get();adminRankingCache=snap.docs.map(d=>({id:d.id,...d.data(),points:Number.isFinite(Number(d.data().points))?Number(d.data().points):(Number(d.data().guardianExp)||0)})).sort((a,b)=>(Number(b.points)||0)-(Number(a.points)||0)||timestampMillis(a.updatedAt)-timestampMillis(b.updatedAt));if(render)renderAdminRanking();
}
function renderAdminRanking(){const list=document.getElementById('adminRankingList');if(!list)return;list.innerHTML=adminRankingCache.length?'':'<div class="empty-ranking">本週沒有排行榜資料。</div>';adminRankingCache.forEach((x,i)=>{const d=document.createElement('div');d.className='admin-data-card';d.innerHTML=`<div><b>${i+1}. ${escapeRankText(x.name||'玩家')}</b><small>本週積分 ${Number(x.points)||0}・金幣 ${Number(x.coins)||0}</small></div>`;list.appendChild(d);});}
async function adminClearRanking(){if(!confirm('確定清空本週排行榜？此操作無法復原。'))return;await loadAdminRanking(false);const batch=cloudDb.batch();adminRankingCache.forEach(x=>batch.delete(cloudDb.collection('weeklyRankings').doc(currentWeekId()).collection('players').doc(x.id)));await batch.commit();toast('本週排行榜已清空');await loadAdminRanking();}
async function adminRebuildRanking(){await loadAdminPlayers(false);let done=0;for(let i=0;i<adminPlayersCache.length;i+=400){const batch=cloudDb.batch();adminPlayersCache.slice(i,i+400).forEach(x=>{const state=x.state||{},av=avatarById(state.avatar);batch.set(cloudDb.collection('weeklyRankings').doc(currentWeekId()).collection('players').doc(x.uid),{uid:x.uid,name:(state.name||x.displayName||'環保守護者').slice(0,12),avatar:av.icon,level:levelFromExp(x.guardianExp),guardianExp:Number(x.guardianExp)||0,coins:Number(x.coins)||0,points:Number(x.guardianExp)||0,completedUnits:Object.values(state.completed||{}).reduce((n,a)=>n+(Array.isArray(a)?a.length:0),0),updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});done++;});await batch.commit();}toast(`已重算 ${done} 位玩家`);await loadAdminRanking();}
async function adminExportRanking(){await loadAdminRanking(false);const rows=[['名次','玩家','UID','守護經驗','金幣'],...adminRankingCache.map((x,i)=>[i+1,x.name||'',x.uid||x.id,Number(x.guardianExp)||0,Number(x.coins)||0])];const csv='\ufeff'+rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\r\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download=`環保冒險王_${currentWeekId()}_排行榜.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}

ensureWeeklyLocal();
document.addEventListener('DOMContentLoaded',()=>{
 const backBtn=document.getElementById('backToStageBtn');
 if(backBtn)backBtn.addEventListener('click',backToStage);
});
window.addEventListener('online',()=>{setCloudStatus('online','☁️ 網路已恢復，正在自動同步。');scheduleCloudSave();});
window.addEventListener('offline',()=>setCloudStatus('offline','⚠️ 目前離線，進度會先保留在本機。'));
initFirebase();


/* ===== V10.2.4 守護基地村雲端同步 ===== */
function publicBaseDoc(){return cloudDb&&cloudUser?cloudDb.collection('publicBases').doc(cloudUser.uid):null}
function normalizePublicPlacement(p){
 return {
  itemId:String(p?.itemId||''),
  x:Math.max(0,Math.min(100,Number(p?.x)||50)),
  y:Math.max(0,Math.min(100,Number(p?.y)||60)),
  scale:Math.max(.55,Math.min(1.8,Number(p?.scale)||1)),
  rotation:((Number(p?.rotation)||0)%360+360)%360,
  mirrored:Boolean(p?.mirrored),
  flowerVariant:Number.isFinite(Number(p?.flowerVariant))?Number(p.flowerVariant):null
 };
}
function publicBasePayload(){
 if(typeof ensureVillageState==='function')ensureVillageState();
 const av=avatarById(st.avatar);
 return {
  uid:cloudUser?.uid||'',
  name:String(st.name||cloudUser?.displayName||'環保守護者').slice(0,12),
  avatar:av.icon,
  avatarId:String(st.avatar||'fox'),
  level:currentLevel(),
  title:String(st.specialTitle||titleForLevel(currentLevel())).slice(0,20),
  intro:String(st.baseIntro||'').slice(0,40),
  placements:(st.basePlacements||[]).slice(0,100).map(normalizePublicPlacement).filter(p=>p.itemId),
  paths:(st.basePaths||[]).slice(0,100),
  badges:typeof S!=='undefined'?S.filter(isDone).length:0,
  visibility:st.baseVisibility==='private'?'private':'public',
  schemaVersion:2
 };
}
function publicBaseFingerprint(payload=publicBasePayload()){
 const stable={...payload};delete stable.uid;
 return JSON.stringify(stable);
}
function updateBaseVillageSyncText(text,mode=''){
 const el=document.getElementById('baseVillageSyncText');
 if(el){el.textContent=text;el.dataset.mode=mode;}
}
function schedulePublicBaseSync(force=false){
 if(!cloudReady||!cloudDb||!cloudUser||!st.loggedIn)return;
 clearTimeout(publicBaseSyncTimer);
 publicBaseSyncTimer=setTimeout(()=>syncPublicBaseNow(force),force?0:700);
}
async function syncPublicBaseNow(force=false){
 if(!cloudDb||!cloudUser||!st.loggedIn)return;
 if(publicBaseWriteInProgress){publicBaseWriteQueued=true;return;}
 publicBaseWriteInProgress=true;
 try{
  if(typeof ensureVillageState==='function')ensureVillageState();
  updateBaseVillageSyncText('☁️ 基地村同步中…','syncing');
  if(st.baseVisibility==='private'){
   await removePublicBase();lastPublicBaseFingerprint='';
   updateBaseVillageSyncText('🔒 私人基地不公開','private');return;
  }
  const payload=publicBasePayload(),fingerprint=publicBaseFingerprint(payload);
  if(!force&&fingerprint===lastPublicBaseFingerprint){updateBaseVillageSyncText('✅ 基地村已同步','saved');return;}
  await savePublicBase(payload);
  lastPublicBaseFingerprint=fingerprint;
  updateBaseVillageSyncText('✅ 基地村已同步','saved');
 }catch(err){
  console.error('守護基地村同步失敗',err);
  updateBaseVillageSyncText('⚠️ 基地村同步失敗','error');
 }finally{
  publicBaseWriteInProgress=false;
  if(publicBaseWriteQueued){publicBaseWriteQueued=false;schedulePublicBaseSync(true);}
 }
}
async function savePublicBase(payload=publicBasePayload()){
 if(!cloudDb||!cloudUser)throw new Error('not signed in');
 const ref=publicBaseDoc();
 const old=await ref.get();const likes=old.exists?Number(old.data().likes)||0:0;
 await ref.set({...payload,uid:cloudUser.uid,likes,updatedAt:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
 lastPublicBaseFingerprint=publicBaseFingerprint(payload);
}
async function removePublicBase(){const ref=publicBaseDoc();if(ref)await ref.delete()}
async function loadPublicBases(){
 if(!cloudDb)return[];
 let snap;
 try{snap=await cloudDb.collection('publicBases').where('visibility','==','public').limit(100).get({source:'server'});}
 catch(err){console.warn('基地村伺服器資料載入失敗，改用快取',err);snap=await cloudDb.collection('publicBases').where('visibility','==','public').limit(100).get();}
 return snap.docs.map(d=>{const x=d.data();return{...x,uid:d.id,updatedAtMs:x.updatedAt&&x.updatedAt.toMillis?x.updatedAt.toMillis():0}});
}
async function sendBaseLike(uid){
 if(!cloudDb||!cloudUser||uid===cloudUser.uid)return;const day=new Date().toISOString().slice(0,10),likeRef=cloudDb.collection('baseLikes').doc(`${day}_${cloudUser.uid}_${uid}`),baseRef=cloudDb.collection('publicBases').doc(uid);
 await cloudDb.runTransaction(async tx=>{const like=await tx.get(likeRef);if(like.exists)return;tx.set(likeRef,{fromUid:cloudUser.uid,toUid:uid,day,createdAt:firebase.firestore.FieldValue.serverTimestamp()});tx.update(baseRef,{likes:firebase.firestore.FieldValue.increment(1)});});
}
